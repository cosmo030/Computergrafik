package app;

import cgg_tools.Vec3;

public record Sizes(Vec3 torso, Vec3 upper_arm, Vec3 forearm, double hand_radius) {

}
