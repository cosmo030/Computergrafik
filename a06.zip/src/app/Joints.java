package app;

public record Joints(double shoulder, double elbow, double wrist) {

}
