package app;

public record Materials(Material torso, Material arm, Material joint) {

}
