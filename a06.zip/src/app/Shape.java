package app;

public interface Shape {
    public Hit intersect(Ray r);
}
